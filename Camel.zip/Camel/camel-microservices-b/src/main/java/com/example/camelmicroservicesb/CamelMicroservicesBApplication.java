package com.example.camelmicroservicesb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelMicroservicesBApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelMicroservicesBApplication.class, args);
	}

}
