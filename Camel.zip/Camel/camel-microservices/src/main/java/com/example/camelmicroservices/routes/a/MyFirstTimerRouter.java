package com.example.camelmicroservices.routes.a;

import org.apache.camel.builder.RouteBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;


//@Component
public class MyFirstTimerRouter extends RouteBuilder {

    @Autowired
    private GetCurrentTimeBean getCurrentTimeBean;

    @Autowired
    private SimpleLoggingProcessingComponent simpleLoggingProcessingComponent;

    @Override
    public void configure() throws Exception {
        // queue (timer) - endpoint
        // transformation
        // database (log) - endpoint
        // these sequence of steps is a route
        from("timer:first-timer")// null
                .log("${body}")
            //transformations
                 .transform().constant("TIME NOW IS " + LocalDateTime.now())
                .log("${body}")
                //.bean(getCurrentTimeBean.class)
                .bean(getCurrentTimeBean, "getCurrentTime")
                .log("${body}")
                .bean(simpleLoggingProcessingComponent, "process")
                .log("${body}")
                .process(new SimpleLoggingProcessor())
                .to("log:first-timer");


        //processing - doesnt change the body
        // transformation - body changes
    }
}

@Component //ideally this should be in its own package.
class GetCurrentTimeBean {
    public String getCurrentTime() {
        return "Time now is " + LocalDateTime.now();
    }
}

@Component
class SimpleLoggingProcessingComponent {

    private Logger logger = LoggerFactory.getLogger(SimpleLoggingProcessingComponent.class);
    public void process(String message) {

        logger.info("SimpleLoggingProcessingComponent {}", message);

    }
}

