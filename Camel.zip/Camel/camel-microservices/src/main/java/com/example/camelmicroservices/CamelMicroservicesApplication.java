package com.example.camelmicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelMicroservicesApplication {

    public static void main(String[] args) {
        SpringApplication.run(CamelMicroservicesApplication.class, args);
    }

}
